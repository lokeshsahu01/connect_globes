from django.contrib import admin
from authy.models import Profile
# Register your models here.

admin.site.register(Profile)