from django.apps import AppConfig


class AuthyConfig(AppConfig):
    name = 'authy'
