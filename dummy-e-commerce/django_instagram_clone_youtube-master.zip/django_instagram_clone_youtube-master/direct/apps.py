from django.apps import AppConfig


class DirectConfig(AppConfig):
    name = 'direct'
