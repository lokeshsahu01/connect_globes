from django.apps import AppConfig


class IcommerceConfig(AppConfig):
    name = 'icommerce'
