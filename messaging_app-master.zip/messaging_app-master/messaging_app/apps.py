from django.apps import AppConfig


class MessagingAppConfig(AppConfig):
    name = 'messaging_app'
