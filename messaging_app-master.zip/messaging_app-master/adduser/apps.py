from django.apps import AppConfig


class AdduserConfig(AppConfig):
    name = 'adduser'
